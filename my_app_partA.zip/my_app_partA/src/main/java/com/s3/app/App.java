package com.s3.app;

import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Exception;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter; 
import java.io.IOException;
import java.io.OutputStream;
import java.util.*;
import java.util.HashMap;
import java.util.Map;

public class App {


    public static void main(String[] args) {
        
        String bucket_name = ""; // your bucket name
        Region region = Region.US_EAST_1;
        String key = "customer.json";

        S3Client s3 = S3Client.builder().region(region).build();

        System.out.println(PutCustomerData(s3, region, bucket_name, "customer.json", "customer.json"));
        System.out.println(GetCustomerData(s3, region, bucket_name, "customer.json"));
        s3.close();
        
    }

    private static String PutCustomerData(S3Client s3, Region region, String bucket_name, String key, String filePath) {

        try {
            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(bucket_name)
                    .key(key)
                    .build();
                    
            PutObjectResponse response = s3.putObject(putObjectRequest, RequestBody.fromBytes(getObjectFile(filePath)));
            System.out.println("Your data is uploaded to S3 bucket");
            return response.eTag();
            
        } catch (S3Exception e) {
            s3.close();
            System.err.println(e.getMessage());
            System.exit(1);
        }
        return "";
    }

    private static byte[] getObjectFile(String filePath) {

        FileInputStream fileInputStream = null;
        byte[] bytesArray = null;

        try {
            File file = new File(filePath);
            bytesArray = new byte[(int) file.length()];
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bytesArray);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return bytesArray;
    }
    
    private static String GetCustomerData(S3Client s3, Region region, String bucket_name, String key) {

        try {
            GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                    .bucket(bucket_name)
                    .key(key)
                    .build();
                    
            ResponseBytes<GetObjectResponse> objectBytes = s3.getObjectAsBytes(getObjectRequest);
            byte[] data = objectBytes.asByteArray();
            FileWriter myWriter = new FileWriter("customer.txt");
            myWriter.write(new String(data));
            myWriter.close();
            System.out.println("Your data is stored in customer.txt");
            return "";

        } catch (Exception e) {
            s3.close();
            System.err.println(e.getMessage());
            System.exit(1);
        }
        return "";
    }

}
