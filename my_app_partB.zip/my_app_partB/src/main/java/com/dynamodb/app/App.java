package com.dynamodb.app;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.PutItemRequest;
import software.amazon.awssdk.services.dynamodb.model.ResourceNotFoundException;
import java.util.HashMap;

public class App {


    public static void main(String[] args) {
        
        PutItems();
        
    }

    private static void PutItems() {

        
        String tableName = "Student";
        Region region = Region.US_EAST_1;
        DynamoDbClient ddb = DynamoDbClient.builder()
                .region(region)
                .build();
        for(int i=0; i<8; i++){
            
            HashMap<String,AttributeValue> itemValues = new HashMap<String,AttributeValue>();
        
            itemValues.put("Id", AttributeValue.builder().n(String.valueOf(i)).build());
            itemValues.put("Name", AttributeValue.builder().s("Student"+String.valueOf(i)).build());
            itemValues.put("EnrollingYear", AttributeValue.builder().n("2020").build()); 
            itemValues.put("CompletedCredit", AttributeValue.builder().n(String.valueOf(i)).build());
            itemValues.put("Address", AttributeValue.builder().s("Address: "+String.valueOf(i)).build());

            PutItemRequest request = PutItemRequest.builder()
                    .tableName(tableName)
                    .item(itemValues)
                    .build();
    
            try {
                ddb.putItem(request);
                System.out.println(tableName +" was successfully updated");
    
            } catch (ResourceNotFoundException e) {
                System.err.format("Error: The Amazon DynamoDB table \"%s\" can't be found.\n", tableName);
                System.err.println("Be sure that it exists and that you've typed its name correctly!");
                System.exit(1);
            } catch (DynamoDbException e) {
                System.err.println(e.getMessage());
                System.exit(1);
            }
        }
    }
    
}

    